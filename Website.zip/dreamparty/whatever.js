const axios = require("axios");


const form = document.getElementById("eventForm");
const nameInput = document.getElementById("name");
const nameError = document.getElementById("nameError");
const familynameInput = document.getElementById("familyname");
const familynameError = document.getElementById("familynameError");
const emailInput = document.getElementById("email");
const emailError = document.getElementById("emailError");
const eventTypeSelect = document.getElementById("eventType");
const eventTypeError = document.getElementById("eventTypeError");
const eventThemeSelect = document.getElementById("eventTheme");
const eventThemeError = document.getElementById("eventThemeError");

form.addEventListener("submit", function(event) {
    event.preventDefault();

    let isValid = true;

    if (!nameInput.value) {
        nameError.textContent = "Name is required";
        nameError.style.display = "block";
        isValid = false;
    } else {
        nameError.style.display = "none";
    }

    if (!familynameInput.value) {
        familynameError.textContent = "Family Name is required";
        familynameError.style.display = "block";
        isValid = false;
    } else {
        familynameError.style.display = "none";
    }

    if (!emailInput.value) {
        emailError.textContent = "Email is required";
        emailError.style.display = "block";
        isValid = false;
    } else if (!/^\w+([.-]?\w+)@\w+([.-]?\w+)(\.\w{2,3})+$/.test(emailInput.value)) {
        emailError.textContent = "Email is invalid";
        emailError.style.display = "block";
        isValid = false;
    } else {
        emailError.style.display = "none";
    }

    if (!eventTypeSelect.value) {
        eventTypeError.textContent = "Event Type is required";
        eventTypeError.style.display = "block";
        isValid = false;
    } else {
        eventTypeError.style.display = "none";
    }

    if (!eventThemeSelect.value) {
        eventThemeError.textContent = "Event Theme is required";
        eventThemeError.style.display = "block";
        isValid = false;
    } else {
        eventThemeError.style.display = "none";
    }

    if (isValid) {
        const formData = {
            name: nameInput.value,
            familyname: familynameInput.value,
            email: emailInput.value,
            eventType: eventTypeSelect.value,
            eventTheme: eventThemeSelect.value
        };
        axios
            .post("http://localhost:3000/send", formData)
            .then(function(response) {
                console.log(response.data);
                alert("Form submitted successfully!");
            })
            .catch(function(error) {
                console.log(error);
                alert("Failed to submit form");
            });
    }
});