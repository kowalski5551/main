const express = require("express");
const nodemailer = require("nodemailer");
const app = express();
const port = 3000;

app.use(express.json());

app.post("/send", (req, res) => {
    const { name, familyname, email, eventType, eventTheme } = req.body;
    const ownerEmail = "evgenzinenko@icloud.com"; // Replace with the email address of the owner
    const transporter = nodemailer.createTransport({
        host: "smtp.office365.com", // Replace with your SMTP host
        port: 587,
        secure: true,
        auth: {
            user: "nathanvannieuwstadt@hotmail.com", // Replace with your email address
            pass: "password" // Replace with your password
        }
    });
    const mailOptions = {
        from: "nathanvannieuwstadt@hotmail.com", // Replace with your email address
        to: ownerEmail,
        subject: "Event Details",
        text: `Name: ${name}\nFamily Name: ${familyname}\nEmail: ${email}\nEvent Type: ${eventType}\nEvent Theme: ${eventTheme}`
    };
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
            res.status(500).send("Failed to send email");
        } else {
            console.log("Email sent: " + info.response);
            res.send("Email sent successfully");
        }
    });
});



app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});